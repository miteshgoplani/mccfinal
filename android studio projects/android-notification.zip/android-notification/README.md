# android-notification
Example code for Android Notifications which contain a confirmation button.

# What it does

The main activity launches a thread which creates three notifications. 
All notifications contain a SNOOZE button. 
If the SNOOZE button is clicked, the notification is canceled and disappears.

Clicking the notification panel does not cancel the notification.
Swiping and "clear all" works as usual.

## Resources

https://developer.android.com/training/notify-user/build-notification#java
